package com.wenzhoong.edition_5;

public class SynLinkedList<E> implements SafeLinkedList<E> {
	private Node<E> head;
	private Object obj;

	public SynLinkedList() {
		this.obj = new Object();
	}

	class Node<E> {
		Node<E> next;
		E value;

		public Node(E e) {
			this.value = e;
		}

		public Node(E e, Node<E> next) {
			this.value = e;
			this.next = next;
		}

		public Node<E> getNext() {
			return next;
		}

		public void setNext(Node<E> node) {
			next = node;
		}

		public E getValue() {
			return value;
		}

		public void setValue(E e) {
			value = e;
		}
	}

	public void push(E e) {
		synchronized (obj) {
			Node<E> newNode = new Node<>(e);
			if (head == null)
				head = newNode;
			else {
				newNode.next = head;
				head = newNode;
			}
		}
	}

	public Node<E> pop() {
		synchronized (obj) {
			Node<E> temp = null;
			if (head != null) {
				temp = head;
				head = head.next;
			}
			return temp;
		}
	}

	public boolean search(E e) {
		synchronized (obj) {
			Node<E> temp = head;
			while (temp != null) {
				if (temp.value.equals(e))
					return true;
				temp = temp.next;
			}
			return false;
		}
	}

	public int numOf() {
		Node<E> temp = head;
		int count = 0;
		while (temp != null) {
			count++;
			temp = temp.next;
		}
		return count;
	}
	
	public void empty() {
		head = null;
	}
	
	public void travel() {
		Node<E> temp = head;
		while(temp != null) {
			System.out.println(temp.value);
			temp = temp.next;
		}
	}
}
