package com.wenzhoong.edition_5;

public class ListEffeciencyTest {

	public static void main(String[] args) {
		
	}

}
