package com.wenzhoong.edition_5;


public interface SafeLinkedList<E> {
	void push(E e);
	
	Object pop();
	
	boolean search(E o);
	
	int numOf();
	
	void empty();
}
