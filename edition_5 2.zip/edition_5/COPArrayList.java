package com.wenzhoong.edition_5;

import java.util.Arrays;
import java.util.concurrent.locks.ReentrantLock;

public class COPArrayList<E> implements SafeList<E>{
	
	private ReentrantLock lock;
	private volatile Object[] list;

	public COPArrayList() {
		this.lock = new ReentrantLock();
		this.list = new Object[0];
	}

	@Override
	public void add(E e) {
		// TODO Auto-generated method stub
		lock.lock();
		Object[] temp = getList();
		int length = temp.length;
		temp = Arrays.copyOf(temp, length+1);
		temp[length] = e;
		setList(temp);
		lock.unlock();
	}

	@Override
	public void add(E e, int index){
		// TODO Auto-generated method stub
		lock.lock();
		Object[] temp = getList();
		int length = temp.length;
		
		if(index<0 || index>length) {
			throw new IndexOutOfBoundsException();
		}
		
		temp = Arrays.copyOf(temp, length+1);
		for(int i = length; i>index; i--) {
			temp[i] = temp[i-1];
		}
		temp[index] = e;
		setList(temp);
//		size++;
		lock.unlock();
	}

	@Override
	public void delete(int index) {
		// TODO Auto-generated method stub
		lock.lock();
		Object[] temp = getList();
		int length = temp.length;
		if(index<0 || index>=length) throw new IndexOutOfBoundsException();
		temp = Arrays.copyOf(temp, length);
		for(int i = index; i<length; i++) {
			temp[i] = temp[i+1];
		}
		temp = Arrays.copyOf(temp, length-1);
		setList(temp);
		lock.unlock();
		
	}

	@Override
	public void delete(E object) {
		// TODO Auto-generated method stub
		lock.lock();
		int index = indexOf(object);
		if(index<0) throw new RuntimeException("Object can not be found.");
		delete(index);
		lock.unlock();
	}
	
	public int indexOf(E object) {
		Object[] list = getList();
		for(int i = 0; i<list.length; i++) {
			if(list[i].equals(object)) return i; 
		}
		return -1;
		
	}
	
	public void empty() {
		list = new Object[0];
	}
	
	public Object[] getList() {
		return list;
	}
	
	public void setList(Object[] list) {
		this.list = list;
	}
	
	public int numOf() {
		return list.length;
	}
}
