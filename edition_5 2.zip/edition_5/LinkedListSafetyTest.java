package com.wenzhoong.edition_5;

import java.util.HashMap;
import java.util.concurrent.CountDownLatch;

public class LinkedListSafetyTest {

	public static void main(String[] args) {
		LockFreeLinkedList<Integer> intList1 = new LockFreeLinkedList<>();
		SynLinkedList<Integer> intList2 = new SynLinkedList<>();
		LockFreeLinkedList<String> strList1 = new LockFreeLinkedList<>();
		SynLinkedList<String> strList2 = new SynLinkedList<>();
		HashMap<String, Boolean> result;
		
		try {
			System.out.println("----------------LockFreeLinkedList<Integer>_Test------------------");
			result = mainTestInt(intList1);
			result.forEach((key, value)->{
				System.out.println(key + ", " + value);
			});		
			System.out.println("----------------SynLinkedList<Integer>_Test------------------");
			result = mainTestInt(intList2);
			result.forEach((key, value)->{
				System.out.println(key + ", " + value);
			});
			System.out.println("----------------LockFreeLinkedList<String>_Test------------------");
			result = mainTestString(strList1);
			result.forEach((key, value)->{
				System.out.println(key + ", " + value);
			});		
			System.out.println("----------------SynLinkedList<String>_Test------------------");
			result = mainTestString(strList2);
			result.forEach((key, value)->{
				System.out.println(key + ", " + value);
			});
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static HashMap<String, Boolean> mainTestInt(SafeLinkedList<Integer> list) throws InterruptedException {
		SafeLinkedList<Integer> temp = list;
		HashMap<String, Boolean> result = new HashMap<>();
		CountDownLatch count = new CountDownLatch(10);
		
			result.put("W_test_1", runningTestWriting(temp, 7, 1));
			temp.empty();
			result.put("W_test_10", runningTestWriting(temp, 7, 10));
			temp.empty();
			result.put("W_test_100", runningTestWriting(temp, 7, 100));
			temp.empty();
			result.put("W_test_1000", runningTestWriting(temp, 7, 1000));
			temp.empty();
			result.put("W_test_10000", runningTestWriting(temp, 7, 10000));
			temp.empty();
			result.put("W_test_100000", runningTestWriting(temp, 7, 100000));
			temp.empty();
			result.put("W_test_1000000", runningTestWriting(temp, 7, 1000000));
			temp.empty();
			
			//创建一个测试数据组
			for(int i = 0; i<10; i++) {
				final int x = i;
				new Thread(()->{
					for(int j = 1000*x; j<1000*x+1000; j++) temp.push(j);
					count.countDown();
				}).start();
			}
			
			count.await();
			//测试所有待查数据都存在的情况
			Integer[] arr1 = {1, 10, 50, 1000, 200, 3000, 400, 500, 5600, 700};
			result.put("R_test_all", runningTestReading(temp, arr1, 10));
			
			//测试部分待查数据存在的情况
			Integer[] arr2 = {-1, 80, 100, 2000, 5678, 345, 678, 99999, 22334, 3456, 12345, 234};
			result.put("R_test_part", runningTestReading(temp, arr2, 8));
			
			//测试所有待查数据都不存在的情况
			Integer[] arr3 = {-23, -45, 33567, -678, -4366};
			result.put("R_test_null", runningTestReading(temp, arr3, 0));
			
			//测试所有待查数据都存在的情况,添加少量数据
			result.put("W&R_test_all_10", runningTestWritingWithReading(temp, 7, 10, arr1, 10));
			//测试部分待查数据存在的情况
			result.put("W&R_test_part_100", runningTestWritingWithReading(temp, 7, 100, arr2, 8));
			//测试所有待查数据都不存在的情况
			result.put("W&R_test_part_1000", runningTestWritingWithReading(temp, 7, 1000, arr3, 0));
			
			return result;
	}
	
	public static HashMap<String, Boolean> mainTestString(SafeLinkedList<String> list) throws InterruptedException {
		SafeLinkedList<String> temp = list;
		HashMap<String, Boolean> result = new HashMap<>();
		CountDownLatch count = new CountDownLatch(10);
		
			result.put("W_test_1", runningTestWriting(temp, "7", 1));
			temp.empty();
			result.put("W_test_10", runningTestWriting(temp, "7", 10));
			temp.empty();
			result.put("W_test_100", runningTestWriting(temp, "7", 100));
			temp.empty();
			result.put("W_test_1000", runningTestWriting(temp, "7", 1000));
			temp.empty();
			result.put("W_test_10000", runningTestWriting(temp, "7", 10000));
			temp.empty();
			result.put("W_test_100000", runningTestWriting(temp, "7", 100000));
			temp.empty();
			result.put("W_test_1000000", runningTestWriting(temp, "7", 1000000));
			temp.empty();
			
			//创建一个测试数据组
			for(int i = 0; i<10; i++) {
				final int x = i;
				new Thread(()->{
					for(int j = 1000*x; j<1000*x+1000; j++) temp.push(j+"");
					count.countDown();
				}).start();
			}
			
			count.await();
			//测试所有待查数据都存在的情况
			String[] arr1 = {"1", "10", "50", "1000", "200", "3000", "400", "500", "5600", "700"};
			result.put("R_test_all", runningTestReading(temp, arr1, 10));
			
			//测试部分待查数据存在的情况
			String[] arr2 = {"-1", "80", "100", "2000", "5678", "345", "678", "99999", "22334", "3456", "12345", "234"};
			result.put("R_test_part", runningTestReading(temp, arr2, 8));
			
			//测试所有待查数据都不存在的情况
			String[] arr3 = {"-23", "-45", "33567", "-678", "-4366"};
			result.put("R_test_null", runningTestReading(temp, arr3, 0));
			
			//测试所有待查数据都存在的情况,添加少量数据
			result.put("W&R_test_all_10", runningTestWritingWithReading(temp, "7", 10, arr1, 10));
			//测试部分待查数据存在的情况
			result.put("W&R_test_part_100", runningTestWritingWithReading(temp, "7", 100, arr2, 8));
			//测试所有待查数据都不存在的情况
			result.put("W&R_test_part_1000", runningTestWritingWithReading(temp, "7", 1000, arr3, 0));
			
			return result;
	}

	public static <E> boolean runningTestWriting(SafeLinkedList<E> list, E element, int num)
			throws InterruptedException {
		SafeLinkedList<E> temp = list;
		int size = temp.numOf();
		CountDownLatch count = new CountDownLatch(10);
		for (int i = 0; i < 10; i++) {
			new Thread(() -> {
				for (int j = 0; j < num; j++)
					temp.push(element);
				count.countDown();
			}).start();
		}

		count.await();
		if (temp.numOf() == (size + 10 * num))
			return true;
		else
			return false;

	}

	public static <E> boolean runningTestWritingWithReading(SafeLinkedList<E> list, E element, int num, E[] aim, int exptNum)
			throws InterruptedException {
		SafeLinkedList<E> temp = list;
		int length = aim.length;
		int size = temp.numOf();
		SafeList<Integer> counter = new SynArrayList<>();
		CountDownLatch count = new CountDownLatch(10+length);

		for (int i = 0; i < 10; i++) {
			new Thread(() -> {
				for (int j = 0; j < num; j++)
					temp.push(element);
				count.countDown();
			}).start();
		}

		for (int i = 0; i < length; i++) {
			final int index = i;
			new Thread(() -> {
				if (temp.search(aim[index]))
					counter.add(index);
				count.countDown();
			}).start();
		}

		count.await();
		if ((temp.numOf() == (size + 10 * num)) && (counter.numOf() == exptNum))
			return true;
		else
			return false;

	}

	public static <E> boolean runningTestReading(SafeLinkedList<E> list, E[] aim, int exptNum)
			throws InterruptedException {
		SafeLinkedList<E> temp = list;
		int length = aim.length;
		CountDownLatch count = new CountDownLatch(length);
		
		SafeList<Integer> counter = new SynArrayList<>();
		for (int i = 0; i < length; i++) {
			final int index = i;
			new Thread(() -> {
				if (temp.search(aim[index]))
					counter.add(index);
				count.countDown();
			}).start();
		}

		count.await();
		if (counter.numOf() == exptNum)
			return true;
		else
			return false;
	}

}
