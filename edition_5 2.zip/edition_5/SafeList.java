package com.wenzhoong.edition_5;

public interface SafeList<E> {
	void add(E e);
	
	void add(E e, int index);
	
	void delete(int index);
	
	void delete(E object);
	
	int indexOf(E object);
	
	int numOf();
	
	void empty();
}
