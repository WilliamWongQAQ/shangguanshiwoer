package com.wenzhoong.edition_5;

import java.util.ArrayList;
import java.util.List;

public class SynArrayList<E> implements SafeList<E> {
	private final List<E> list;
	
	public SynArrayList() {
		this.list = new ArrayList<>();
	}

	@Override
	public synchronized void add(E e) {
		// TODO Auto-generated method stub
			list.add(e);

	}

	@Override
	public synchronized void add(E e, int index) {
		// TODO Auto-generated method stub
		if(index < 0 || index > list.size()) throw new ArrayIndexOutOfBoundsException();
			list.add(index, e);
	}

	@Override
	public synchronized void delete(int index) {
		// TODO Auto-generated method stub
			list.remove(index);
	}

	@Override
	public synchronized void delete(E object) {
		// TODO Auto-generated method stub
			list.remove(object);
	}

	@Override
	public synchronized int indexOf(E object) {
		// TODO Auto-generated method stub
			return list.indexOf(object);
	}
	
	public int numOf() {
		return list.size();
	}
	
	public void empty() {
		list.clear();
	}
}
