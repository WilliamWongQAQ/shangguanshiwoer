package com.wenzhoong.edition_5;

import java.util.HashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

public class ListSafetyTest {

	public static void main(String[] args) {
		SafeList<Integer> intList1 = new SynArrayList<>();
		SafeList<Integer> intList2 = new COPArrayList<>();
		SafeList<String> strList1 = new SynArrayList<>();
		SafeList<String> strList2 = new COPArrayList<>();
		HashMap<String, Boolean> result;
		
		try {
			System.out.println("----------------SynArrayList<Integer>_Test------------------");
			result = mainTestInt(intList1);
			result.forEach((key, value)->{
				System.out.println(key + ", " + value);
			});		
			System.out.println("----------------COPArrayList<Integer>_Test------------------");
			result = mainTestInt(intList2);
			result.forEach((key, value)->{
				System.out.println(key + ", " + value);
			});
			System.out.println("----------------SynArrayList<String>_Test------------------");
			result = mainTestString(strList1);
			result.forEach((key, value)->{
				System.out.println(key + ", " + value);
			});	
			System.out.println("----------------COPArrayList<String>_Test------------------");
			result = mainTestString(strList2);
			result.forEach((key, value)->{
				System.out.println(key + ", " + value);
			});
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static HashMap<String, Boolean> mainTestInt(SafeList<Integer> list) throws InterruptedException {
		SafeList<Integer> temp = list;
		HashMap<String, Boolean> result = new HashMap<>();
		CountDownLatch count = new CountDownLatch(10);
		
			result.put("A_test_1", addTest(temp, 7, 1));
			temp.empty();
			result.put("A_test_10", addTest(temp, 7, 10));
			temp.empty();
			result.put("A_test_100", addTest(temp, 7, 100));
			temp.empty();
			result.put("A_test_1000", addTest(temp, 7, 1000));
			temp.empty();
			result.put("A_test_10000", addTest(temp, 7, 10000));
			temp.empty();
//			result.put("A_test_100000", addTest(temp, 7, 100000));
//			temp.empty();
//			result.put("A_test_1000000", addTest(temp, 7, 1000000));
//			temp.empty();
			
			//创建一个测试数据组
			for(int i = 0; i<10; i++) {
				final int x = i;
				new Thread(()->{
					for(int j = 1000*x; j<1000*x+1000; j++) temp.add(j);
					count.countDown();
				}).start();
			}
			
			count.await();
			//测试所有待查数据都存在的情况
			Integer[] arr1 = {1, 10, 50, 1000, 200, 3000, 400, 500, 5600, 700};
			result.put("S_test_all", searchTest(temp, arr1, 10));
			
			//测试部分待查数据存在的情况
			Integer[] arr2 = {-1, 80, 100, 2000, 5678, 345, 678, 99999, 22334, 3456, 12345, 234};
			result.put("S_test_part", searchTest(temp, arr2, 8));
			
			//测试所有待查数据都不存在的情况
			Integer[] arr3 = {-23, -45, 33567, -678, -4366};
			result.put("S_test_null", searchTest(temp, arr3, 0));
			
			//测试所有待查数据都存在的情况,添加少量数据
			result.put("A&S_test_all_10", addAndSearchTest(temp, 7, 10, arr1, 10));
			//测试部分待查数据存在的情况
			result.put("A&S_test_part_100", addAndSearchTest(temp, 7, 100, arr2, 8));
			//测试所有待查数据都不存在的情况
			result.put("A&S_test_part_1000", addAndSearchTest(temp, 7, 1000, arr3, 0));
			
//			addIndexTest(temp, 9, 10);
//			
//			addIndexTest(temp, 9, 100);
//			
//			addIndexTest(temp, 9, 1000);
			
			return result;
	}
	
	public static HashMap<String, Boolean> mainTestString(SafeList<String> list) throws InterruptedException {
		SafeList<String> temp = list;
		HashMap<String, Boolean> result = new HashMap<>();
		CountDownLatch count = new CountDownLatch(10);
		
			result.put("A_test_1", addTest(temp, "7", 1));
			temp.empty();
			result.put("A_test_10", addTest(temp, "7", 10));
			temp.empty();
			result.put("A_test_100", addTest(temp, "7", 100));
			temp.empty();
			result.put("A_test_1000", addTest(temp, "7", 1000));
			temp.empty();
			result.put("A_test_10000", addTest(temp, "7", 10000));
			temp.empty();
//			result.put("A_test_100000", addTest(temp, "7", 100000));
//			temp.empty();
//			result.put("A_test_1000000", addTest(temp, "7", 1000000));
//			temp.empty();
			
			//创建一个测试数据组
			for(int i = 0; i<10; i++) {
				final int x = i;
				new Thread(()->{
					for(int j = 1000*x; j<1000*x+1000; j++) temp.add(j + "");
					count.countDown();
				}).start();
			}
			
			count.await();
			//测试所有待查数据都存在的情况
			String[] arr1 = {"1", "10", "50", "1000", "200", "3000", "400", "500", "5600", "700"};
			result.put("S_test_all", searchTest(temp, arr1, 10));
			
			//测试部分待查数据存在的情况
			String[] arr2 = {"-1", "80", "100", "2000", "5678", "345", "678", "99999", "22334", "3456", "12345", "234"};
			result.put("S_test_part", searchTest(temp, arr2, 8));
			
			//测试所有待查数据都不存在的情况
			String[] arr3 = {"-23", "-45", "33567", "-678", "-4366"};
			result.put("S_test_null", searchTest(temp, arr3, 0));
			
			//测试所有待查数据都存在的情况,添加少量数据
			result.put("A&S_test_all_10", addAndSearchTest(temp, "7", 10, arr1, 10));
			//测试部分待查数据存在的情况
			result.put("A&S_test_part_100", addAndSearchTest(temp, "7", 100, arr2, 8));
			//测试所有待查数据都不存在的情况
			result.put("A&S_test_part_1000", addAndSearchTest(temp, "7", 1000, arr3, 0));
			
//			addIndexTest(temp, 9, 10);
//			
//			addIndexTest(temp, 9, 100);
//			
//			addIndexTest(temp, 9, 1000);
			
			return result;
	}
	
	public static <E> boolean addTest(SafeList<E> list, E element, int num)
			throws InterruptedException {
		SafeList<E> temp = list;
		int size = temp.numOf();
		CountDownLatch count = new CountDownLatch(10);
		for (int i = 0; i < 10; i++) {
			new Thread(() -> {
				for (int j = 0; j < num; j++)
					temp.add(element);
				count.countDown();
			}).start();
		}
		
		count.await();
		if (temp.numOf() == (size + 10 * num))
			return true;
		else
			return false;

	}
	
	public static <E> boolean addIndexTest(SafeList<E> list, E element, int num)
			throws InterruptedException {
		SafeList<E> temp = list;
		int size = temp.numOf();
		CountDownLatch count = new CountDownLatch(10);
		
		for (int i = 0; i < 10; i++) {
			new Thread(() -> {
				for (int j = 0; j < num; j++)
					temp.add(element, size*j/num);
				count.countDown();
			}).start();
		}
		
		count.await();
		if (temp.numOf() == (size + 10 * num))
			return true;
		else
			return false;

	}

	public static <E> boolean addAndSearchTest(SafeList<E>list, E element, int num, E[] aim, int exptNum)
			throws InterruptedException {
		SafeList<E> temp = list;
		int length = aim.length;
		int size = temp.numOf();
		AtomicInteger counter = new AtomicInteger(0);
		CountDownLatch count = new CountDownLatch(10+length);

		for (int i = 0; i < 10; i++) {
			new Thread(() -> {
				for (int j = 0; j < num; j++)
					temp.add(element);
				count.countDown();
			}).start();
		}

		for (int i = 0; i < length; i++) {
			final int index = i;
			new Thread(() -> {
				if (temp.indexOf(aim[index]) >= 0)
					counter.incrementAndGet();
				count.countDown();
			}).start();
		}

		count.await();
		if ((temp.numOf() == (size + 10 * num)) && (counter.get() == exptNum))
			return true;
		else
			return false;

	}

	public static <E> boolean searchTest(SafeList<E> list, E[] aim, int exptNum)
			throws InterruptedException {
		SafeList<E> temp = list;
		int length = aim.length;
		CountDownLatch count = new CountDownLatch(length);
		
		AtomicInteger counter = new AtomicInteger(0);
		for (int i = 0; i < length; i++) {
			final int index = i;
			new Thread(() -> {
				if (temp.indexOf(aim[index]) >= 0)
					counter.getAndIncrement();
				count.countDown();
			}).start();
		}

		count.await();
		if (counter.get() == exptNum)
			return true;
		else
			return false;
	}
	
}
